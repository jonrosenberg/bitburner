export async function main(ns) { let r;try{r=JSON.stringify(
    Object.fromEntries(JSON.parse(ns.args[0]).map(c => [c.contract, ns.codingcontract.getData(c.contract, c.hostname)]))
);}catch(e){r="ERROR: "+(typeof e=='string'?e:e.message||JSON.stringify(e));}
const f="/Temp/contract-data.txt"; if(ns.read(f)!==r) ns.write(f,r,'w') }